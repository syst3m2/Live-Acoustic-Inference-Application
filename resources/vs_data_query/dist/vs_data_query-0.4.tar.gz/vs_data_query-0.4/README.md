# VS_data_query

This repository contains a python interface for the Monterey Accelerated Research Station (MARS) hydrophone data.

## Installation

Install through pip with

`pip install git+https://gitlab.nps.edu/vector-sensor-processing/python/vs_data_query.git`

## Usage

### Creating a crawler

### Getting Samples

